package com.example.tracnghiemtest.Database;

public class MethodNamesTable {
    final static String METHOD_1 = "getFullExamInfor";
    final static String METHOD_2 = "getAPartExamInfor";
    final static String METHOD_3 = "getDSLop";
    final static String METHOD_4 = "getLop";
    final static String METHOD_5 = "getDSMon";
    final static String METHOD_6 = "insertDeThi";
    final static String METHOD_7 = "getDeThi";
    final static String METHOD_8 = "getExamInfor";
    final static String METHOD_9 = "processExam";
    final static String METHOD_10 = "insertdataCauHoi";
    final static String METHOD_11 = "insertdataDapAn";
    final static String METHOD_12 = "getDSDeThi";
    final static String METHOD_13 = "setStatus";
    final static String METHOD_14 = "deleteDeThi";




}
